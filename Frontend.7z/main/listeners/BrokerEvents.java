package main.listeners;

import main.Broker;
import main.sql.BrokerSQL;
import main.sql.OrdersSQL;
import main.sql.StocksSQL;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.Locale;

public class BrokerEvents extends ListenerAdapter {
    public static TextChannel logChannel;
    public static TextChannel depositWithdrawChannel;
    public static TextChannel publicTradeChannel;

    public static TextChannel removedOrdersChannel;
    @Override
    public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event)
    {
        String senderID = event.getMember().getId();
         logChannel = event.getGuild().getChannelById(TextChannel.class, "1007449573180063876");
         depositWithdrawChannel = event.getGuild().getChannelById(TextChannel.class, "1007449878949019729");
        removedOrdersChannel = event.getGuild().getChannelById(TextChannel.class, "1007449769876127764");
        publicTradeChannel = event.getGuild().getChannelById(TextChannel.class, "917415977023582238");

        Role trader = event.getGuild().getRoleById("1007453371948617758");


        User sender = event.getUser();
        Instant instant = Instant.now();
        ZoneId z = ZoneId.of( "America/New_York" );
        ZonedDateTime zdt = instant.atZone( z );
        boolean isMidnight;
        if(zdt.getHour() == 0)
        {
            isMidnight = true;
        } else {
            isMidnight = false;
        }



        if(event.getMember().getRoles().contains(event.getGuild().getRoleById("1007453371948617758")))
        {


            if(event.getName().equals("help"))
            {

                EmbedBuilder eb = new EmbedBuilder();
                eb.setTitle("Broker Help");
                eb.setColor(new Color(0xbb8fce));
                eb.addField("Help", "<:reply:1030556217245970502>Shows available commands", false);
                eb.addField("Balance", "<:reply:1030556217245970502>Shows your available balance", false);
                eb.addField("Portfolio", "<:reply:1030556217245970502>Displays your portfolio", false);
                eb.addField("Orders", "<:reply:1030556217245970502>Lists orders", false);
                eb.addField("Info <ticker>", "<:reply:1030556217245970502>Shows stock ticker information", false);
                eb.addField("Buy <ticker> <amount>", "<:reply:1030556217245970502>Purchases a security", false);
                eb.addField("Sell <ticker> <amount>", "<:reply:1030556217245970502>Sells a security", false);
                eb.addField("Remove <type> <ticker> <id>", "<:reply:1030556217245970502>Removes an order", false);

                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                event.deferReply().setEphemeral(true).queue();
                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

            }

            if(event.getName().equals("balance"))
            {
                try {
                    if(BrokerSQL.isRegistered(senderID))
                    {
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Balance");
                        eb.setColor(new Color(0xbb8fce));
                        try {
                            eb.addField("You have:", BrokerSQL.getBalance(event.getMember().getId()), true);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    } else {
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Whoops!");
                        eb.setColor(Color.RED);
                        eb.setDescription("You aren't registered!");
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

            }

            if(event.getName().equals("portfolio"))
            {

                try {
                    if(BrokerSQL.isRegistered(senderID))
                    {
                        EmbedBuilder eb;


                        try {
                            eb = BrokerSQL.getPortfolio(senderID);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        eb.setColor(new Color(0xbb8fce));
                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    } else {
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Whoops!");
                        eb.setColor(Color.RED);
                        eb.setDescription("You aren't registered!");
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }

            if(event.getName().equals("orders"))
            {
                ResultSet r;
                try {
                    if(BrokerSQL.isRegistered(senderID))
                    {


                        try {
                            r = OrdersSQL.getOrders(senderID);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Orders");
                        eb.setColor(new Color(0xbb8fce));
                        while(r.next())
                        {
                            String transactionID = r.getString("transactionId");
                            String ticker = r.getString("ticker");
                            int shares = r.getInt("numShares");
                            String type = r.getString("orderType");

                            eb.addField("Order ID: " + transactionID + " | Type: " + type.toUpperCase(), "Ticker: " + ticker + " | Shares: " + shares, false);
                        }
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");


                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    } else {
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Whoops!");
                        eb.setColor(Color.RED);
                        eb.setDescription("You aren't registered!");
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }

            if(event.getName().equals("info"))
            {
                OptionMapping tickerOption = event.getOption("ticker");
                String ticker = tickerOption.getAsString();

                EmbedBuilder eb;
                try {
                    eb = StocksSQL.getInfoEmbed(ticker);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                event.deferReply().setEphemeral(true).queue();
                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
            }

            if(event.getName().equals("companies"))
            {
                EmbedBuilder eb;
                try {
                    eb = StocksSQL.getCompanies();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                event.deferReply().setEphemeral(true).queue();
                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
            }

            if(event.getName().equals("buy"))
            {


                    OptionMapping tickerOption = event.getOption("ticker");
                    OptionMapping amountOption = event.getOption("amount");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    int amount = amountOption.getAsInt();
                    double paid = 0;
                    try {
                        if(BrokerSQL.isRegistered(senderID))
                        {
                            if(isMidnight)
                            {
                                EmbedBuilder eb = new EmbedBuilder();
                                eb.setTitle("Whoops!");
                                eb.setColor(Color.RED);
                                eb.setDescription("You cannot trade between midnight and 1AM (EST)!");
                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                            } else {
                                if(amount <= 0)
                                {
                                    EmbedBuilder eb = new EmbedBuilder();
                                    eb.setTitle("Whoops!");
                                    eb.setColor(Color.RED);
                                    eb.setDescription("You cannot buy 0 or less shares!");
                                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                } else {
                                    if (BrokerSQL.userIsFrozen(senderID)) {
                                        EmbedBuilder eb = new EmbedBuilder();
                                        eb.setTitle("Whoops!");
                                        eb.setColor(Color.RED);
                                        eb.setDescription("Your account is frozen!");
                                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                        event.deferReply().setEphemeral(true).queue();
                                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                    } else {
                                        try {
                                            if (StocksSQL.buy(ticker, senderID, amount, sender)) {
                                                EmbedBuilder eb = new EmbedBuilder();
                                                eb.setTitle(ticker + " - BUY ORDER");
                                                eb.setColor(Color.GREEN);
                                                eb.addField("SUCCESS", "ORDER RECORDED!", false);
                                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                                event.deferReply().setEphemeral(true).queue();
                                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            } else {
                                                EmbedBuilder eb = new EmbedBuilder();
                                                eb.setTitle(ticker + " - BUY ORDER");
                                                eb.setColor(Color.GREEN);
                                                eb.addField("FAILURE", "ORDER FAILED!", false);
                                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                                event.deferReply().setEphemeral(true).queue();
                                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            }
                                        } catch (SQLException e) {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle(ticker + " - BUY ORDER");
                                            eb.setColor(Color.RED);
                                            eb.addField("ERROR", "Please Alert Staff!", false);
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            throw new RuntimeException(e);

                                        }
                                    }


                                }
                            }







                        } else {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Whoops!");
                            eb.setColor(Color.RED);
                            eb.setDescription("You aren't registered!");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }





            }

            if(event.getName().equals("remove"))
            {

                    OptionMapping orderTypeOption = event.getOption("type");
                    OptionMapping transactionIdTypeOption = event.getOption("id");
                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    String transactionId = transactionIdTypeOption.getAsString();
                    String orderType = orderTypeOption.getAsString().toLowerCase();


                    try {
                        if(BrokerSQL.isRegistered(senderID))
                        {
                            if(BrokerSQL.userIsFrozen(senderID)) {
                                EmbedBuilder eb = new EmbedBuilder();
                                eb.setTitle("Whoops!");
                                eb.setColor(Color.RED);
                                eb.setDescription("Your account is frozen!");
                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                            } else {
                                if(isMidnight)
                                {
                                    EmbedBuilder eb = new EmbedBuilder();
                                    eb.setTitle("Whoops!");
                                    eb.setColor(Color.RED);
                                    eb.setDescription("You cannot trade between midnight and 1AM (EST)!");
                                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                } else {
                                    if (orderType.equals("buy")) {
                                        if (OrdersSQL.removeBuy(ticker, transactionId, senderID)) {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle("Order Removed!");
                                            eb.setDescription("Order ID: " + transactionId);
                                            eb.setColor(Color.GREEN);
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                                            removedOrdersChannel.sendMessage("User: " + senderID + " Removed Order: " + transactionId).queue();
                                            sendMessage(sender, "You removed order with transaction ID " + transactionId);
                                        } else {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle("Order Removal Failed!");
                                            eb.setColor(Color.RED);
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                        }

                                    } else if (orderType.equals("sell")) {
                                        if (OrdersSQL.removeSell(ticker, transactionId, senderID)) {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle("Order Removed!");
                                            eb.setDescription("Order ID: " + transactionId);
                                            eb.setColor(Color.GREEN);
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                                            removedOrdersChannel.sendMessage("User: " + senderID + " Removed Order: " + transactionId).queue();
                                            sendMessage(sender, "You removed order with transaction ID " + transactionId);
                                        } else {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle("Order Removal Failed!");
                                            eb.setColor(Color.RED);
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                        }


                                    } else {
                                        EmbedBuilder eb = new EmbedBuilder();
                                        eb.setTitle("Whoops!");
                                        eb.setColor(Color.RED);
                                        eb.setDescription("Order type not valid!");
                                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                        event.deferReply().setEphemeral(true).queue();
                                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                    }
                                }




                            }
                        } else {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Whoops!");
                            eb.setColor(Color.RED);
                            eb.setDescription("You aren't registered!");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


            }

            if(event.getName().equals("sell"))
            {

                    OptionMapping tickerOption = event.getOption("ticker");
                    OptionMapping amountOption = event.getOption("amount");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    int amount = amountOption.getAsInt();

                    try {
                        if(BrokerSQL.isRegistered(senderID))
                        {
                            if(isMidnight)
                            {
                                EmbedBuilder eb = new EmbedBuilder();
                                eb.setTitle("Whoops!");
                                eb.setColor(Color.RED);
                                eb.setDescription("You cannot trade between midnight and 1AM (EST)!");
                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                            } else {
                                if(amount <= 0)
                                {
                                    EmbedBuilder eb = new EmbedBuilder();
                                    eb.setTitle("Whoops!");
                                    eb.setColor(Color.RED);
                                    eb.setDescription("You cannot sell 0 or less shares!");
                                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                } else {
                                    if (BrokerSQL.userIsFrozen(senderID)) {
                                        EmbedBuilder eb = new EmbedBuilder();
                                        eb.setTitle("Whoops!");
                                        eb.setColor(Color.RED);
                                        eb.setDescription("Your account is frozen!");
                                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                        event.deferReply().setEphemeral(true).queue();
                                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                    } else {


                                        try {
                                            if (StocksSQL.sell(ticker, senderID, amount, sender)) {
                                                EmbedBuilder eb = new EmbedBuilder();
                                                eb.setTitle(ticker + " - SELL ORDER");
                                                eb.setColor(Color.GREEN);
                                                eb.addField("SUCCESS", "ORDER RECORDED!", false);
                                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                                event.deferReply().setEphemeral(true).queue();
                                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            } else {
                                                EmbedBuilder eb = new EmbedBuilder();
                                                eb.setTitle(ticker + " - SELL ORDER");
                                                eb.setColor(Color.RED);
                                                eb.addField("FAILURE", "ORDER FAILED!", false);
                                                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                                eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                                event.deferReply().setEphemeral(true).queue();
                                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            }
                                        } catch (SQLException e) {
                                            EmbedBuilder eb = new EmbedBuilder();
                                            eb.setTitle(ticker + " - SELL ORDER");
                                            eb.setColor(Color.RED);
                                            eb.addField("ERROR", "Please Alert Staff!", false);
                                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                            event.deferReply().setEphemeral(true).queue();
                                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                                            throw new RuntimeException(e);
                                        }
                                    }
                                }
                            }


                        } else {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Whoops!");
                            eb.setColor(Color.RED);
                            eb.setDescription("You aren't registered!");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


            }

            if(event.getName().equals("deposit"))
            {


                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping idOption = event.getOption("id");
                    OptionMapping amountOption = event.getOption("amount");
                    String id = idOption.getAsString();
                    double amount = amountOption.getAsDouble();

                    try {
                        BrokerSQL.deposit(id, amount, "**ACCOUNT DEPOSIT**");
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }

                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("DEPOSIT");
                    eb.setColor(new Color(0xbb8fce));
                    eb.setDescription(BrokerSQL.nf.format(amount) + " deposited");
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("withdraw"))
            {


                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping idOption = event.getOption("id");
                    OptionMapping amountOption = event.getOption("amount");
                    String id = idOption.getAsString();
                    double amount = amountOption.getAsDouble();

                    try {
                        if(BrokerSQL.withdraw(id, amount,"**ACCOUNT WITHDRAWAL**"))
                        {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("WITHDRAW");
                            eb.setColor(new Color(0xbb8fce));
                            eb.setDescription(BrokerSQL.nf.format(amount) + " withdrawn");
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        } else {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("WITHDRAWAL FAILED");
                            eb.setColor(Color.RED);
                            eb.setDescription("There is not enough money in this account to withdraw  " + BrokerSQL.nf.format(amount));
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }
            }

            if(event.getName().equals("register"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")) || event.getMember().getRoles().contains(event.getGuild().getRoleById("873413694678265856")))
                {
                    OptionMapping idOption = event.getOption("id");
                    OptionMapping ignOption = event.getOption("ign");
                    String ign = ignOption.getAsString();
                    String id = idOption.getAsString();
                    try{
                        if(BrokerSQL.registerUser(id, ign)){
                            event.getGuild().addRoleToMember(event.getMember(), trader).queue();
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Account Created!");
                            eb.addField("ID:",id, true);
                            eb.setColor(new Color(0xbb8fce));
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        } else {
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setColor(Color.RED);
                            eb.setTitle("Account Creation Failed");
                            eb.addField("",id + " Already Exists!", true);
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }


                    } catch (Exception e) {
                        System.out.println(e);
                    }



                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("create"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping tickerOption = event.getOption("ticker");
                    OptionMapping priceOption = event.getOption("price");
                    OptionMapping amountOption = event.getOption("amount");
                    OptionMapping fullOption = event.getOption("full");
                    OptionMapping totalOption = event.getOption("total");
                    int total = totalOption.getAsInt();
                    String fullName = fullOption.getAsString();
                    String ticker = tickerOption.getAsString().toLowerCase();
                    double price = priceOption.getAsDouble();
                    int amount = amountOption.getAsInt();

                    try {
                        StocksSQL.addStock(ticker, fullName, price, amount, total);
                        OrdersSQL.createBuyTable(ticker);
                        OrdersSQL.createSellTable(ticker);
                    } catch (SQLException e) {
                        System.out.println(e);
                        throw new RuntimeException(e);

                    }

                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Stock Added!");
                    eb.setColor(Color.GREEN);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("freeze"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    EmbedBuilder eb = new EmbedBuilder();

                    try {
                        if(BrokerSQL.freezeStock(ticker))
                        {
                            eb.setTitle(ticker + " FROZEN!");
                            eb.setColor(new Color(0xbb8fce));
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                        }else{
                            eb.setTitle(ticker + " FAILED TO FREEZE!");
                            eb.setColor(Color.RED);
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                        }
                    } catch (SQLException e) {
                        System.out.println(e);
                        throw new RuntimeException(e);

                    }



                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("unfreeze"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    EmbedBuilder eb = new EmbedBuilder();

                    try {
                        if(BrokerSQL.unfreezeStock(ticker))
                        {
                            eb.setTitle(ticker + " UNFROZEN!");
                            eb.setColor(new Color(0xbb8fce));
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                        }else{
                            eb.setTitle(ticker + " FAILED TO UNFREEZE!");
                            eb.setColor(Color.RED);
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();

                        }
                    } catch (SQLException e) {
                        System.out.println(e);
                        throw new RuntimeException(e);

                    }



                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("aportfolio"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping idOption = event.getOption("id");
                    String id = idOption.getAsString().toLowerCase();

                    try {
                        if(BrokerSQL.isRegistered(id))
                        {
                            EmbedBuilder eb;


                            try {
                                eb = BrokerSQL.getPortfolio(id);
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                            eb.setColor(new Color(0xbb8fce));
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This user isn't registered!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("shareholders"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();

                    try {
                        if(StocksSQL.stockExists(ticker))
                        {
                            EmbedBuilder eb;


                            try {
                                eb = BrokerSQL.getShareholders(ticker);
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                            eb.setColor(new Color(0xbb8fce));
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This stock doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("userfreeze"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping idOption = event.getOption("id");
                    String id = idOption.getAsString();

                    try {
                        if(BrokerSQL.isRegistered(id))
                        {

                            try {
                                BrokerSQL.freezeUser(id);
                                EmbedBuilder eb = new EmbedBuilder();
                                eb.setDescription("User with ID: " + id + " is now frozen from trading!");
                                eb.setColor(new Color(0xbb8fce));
                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                            } catch (SQLException e) {
                                EmbedBuilder error = new EmbedBuilder();
                                error.setTitle("Whoops!");
                                error.setColor(Color.RED);
                                error.setDescription("Error freezing user!");
                                error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                throw new RuntimeException(e);
                            }

                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This user doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("userunfreeze"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {

                    OptionMapping idOption = event.getOption("id");
                    String id = idOption.getAsString();

                    try {
                        if(BrokerSQL.isRegistered(id))
                        {

                            try {
                                BrokerSQL.unfreezeUser(id);
                                EmbedBuilder eb = new EmbedBuilder();
                                eb.setDescription("User with ID: " + id + " is now unfrozen from trading!");
                                eb.setColor(new Color(0xbb8fce));
                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                            } catch (SQLException e) {
                                EmbedBuilder error = new EmbedBuilder();
                                error.setTitle("Whoops!");
                                error.setColor(Color.RED);
                                error.setDescription("Error unfreezing user!");
                                error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                event.deferReply().setEphemeral(true).queue();
                                event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                throw new RuntimeException(e);
                            }

                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This user doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("takeshares"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping userIdOption = event.getOption("id");
                    String userId = userIdOption.getAsString();
                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    OptionMapping amountOption = event.getOption("amount");
                    int amount = amountOption.getAsInt();

                    try {
                        if(StocksSQL.stockExists(ticker))
                        {
                            if(BrokerSQL.isRegistered(userId))
                            {
                                if(BrokerSQL.getUsersShares(ticker, userId) <= amount)
                                {
                                    try {
                                        BrokerSQL.takeShares(ticker, amount, userId);
                                        logChannel.sendMessage(amount + " shares of " + ticker + " taken from user with ID " + userId).queue();
                                        EmbedBuilder error = new EmbedBuilder();
                                        error.setTitle("Shares Taken!");
                                        error.setColor(Color.GREEN);
                                        error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                        error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                        event.deferReply().setEphemeral(true).queue();
                                        event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                    } catch (SQLException e) {
                                        EmbedBuilder error = new EmbedBuilder();
                                        error.setTitle("Whoops!");
                                        error.setColor(Color.RED);
                                        error.setDescription("Error taking shares!!");
                                        error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                        error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                        event.deferReply().setEphemeral(true).queue();
                                        event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                        throw new RuntimeException(e);
                                    }
                                } else {
                                    EmbedBuilder error = new EmbedBuilder();
                                    error.setTitle("Whoops!");
                                    error.setColor(Color.RED);
                                    error.setDescription("User !");
                                    error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                }

                            }



                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This stock doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }
            if(event.getName().equals("grantshares"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping userIdOption = event.getOption("id");
                    String userId = userIdOption.getAsString();
                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    OptionMapping amountOption = event.getOption("amount");
                    int amount = amountOption.getAsInt();

                    try {
                        if(StocksSQL.stockExists(ticker))
                        {
                            if(BrokerSQL.isRegistered(userId))
                            {
                                try {
                                    BrokerSQL.giveShares(ticker, amount, userId);
                                    logChannel.sendMessage(amount + " shares of " + ticker + " granted to user with ID " + userId).queue();
                                    EmbedBuilder error = new EmbedBuilder();
                                    error.setTitle("Shares Granted!");
                                    error.setColor(Color.GREEN);
                                    error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                } catch (SQLException e) {
                                    EmbedBuilder error = new EmbedBuilder();
                                    error.setTitle("Whoops!");
                                    error.setColor(Color.RED);
                                    error.setDescription("Error granting shares!!");
                                    error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                                    error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                                    event.deferReply().setEphemeral(true).queue();
                                    event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                                    throw new RuntimeException(e);
                                }
                            }



                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This stock doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("abalance"))
            {


                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping idOption = event.getOption("id");
                    String id = idOption.getAsString();

                    try {
                        if(BrokerSQL.isRegistered(id))
                        {
                            String balance = BrokerSQL.getBalance(id);
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Balance");
                            eb.setColor(new Color(0xbb8fce));
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            eb.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
                            eb.addField("Account Number:",id,false);
                            eb.addField("Balance:",balance,false);

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }else{
                            EmbedBuilder eb = new EmbedBuilder();
                            eb.setTitle("Not Registered.");
                            eb.setColor(Color.RED);
                            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        }

                    } catch (SQLException e) {
                        EmbedBuilder eb = new EmbedBuilder();
                        eb.setTitle("Error!");
                        eb.setColor(Color.RED);
                        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                        event.deferReply().setEphemeral(true).queue();
                        event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }

            if(event.getName().equals("setvaluation"))
            {

                if(event.getMember().getRoles().contains(event.getGuild().getRoleById("929101550310260807")))
                {
                    OptionMapping tickerOption = event.getOption("ticker");
                    String ticker = tickerOption.getAsString().toLowerCase();
                    OptionMapping valuationOption = event.getOption("valuation");
                    double valuation = valuationOption.getAsDouble();
                    OptionMapping sharesOption = event.getOption("shares");
                    int shares = sharesOption.getAsInt();

                    try {
                        if (StocksSQL.stockExists(ticker)) {
                            double oldPrice = StocksSQL.getPrice(ticker);
                            double newPrice = StocksSQL.updatePriceFromValuation(valuation, shares, ticker);
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("PRICE UPDATED FOR " + ticker.toUpperCase());
                            error.setColor(Color.GREEN);
                            error.setDescription("NEW PRICE " + BrokerSQL.nf.format(newPrice) + "\nOLD PRICE " + BrokerSQL.nf.format(oldPrice));
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        } else {
                            EmbedBuilder error = new EmbedBuilder();
                            error.setTitle("Whoops!");
                            error.setColor(Color.RED);
                            error.setDescription("This stock doesn't exist!");
                            error.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                            error.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

                            event.deferReply().setEphemeral(true).queue();
                            event.getHook().sendMessageEmbeds(error.build()).setEphemeral(true).queue();
                        }





                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }


                } else {
                    EmbedBuilder eb = new EmbedBuilder();
                    eb.setTitle("Not Authenticated!");
                    eb.setColor(Color.RED);
                    eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
                    eb.addField("","Only Exchange Personnel can execute this command!", true);
                    eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                    event.deferReply().setEphemeral(true).queue();
                    event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
                }

            }



        } else {
            EmbedBuilder eb = new EmbedBuilder();
            eb.setTitle("Not Authenticated!");
            eb.setColor(Color.RED);
            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
            eb.addField("","The Trader role is required to use the Broker bot!", true);
            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
            event.deferReply().setEphemeral(true).queue();
            event.getHook().sendMessageEmbeds(eb.build()).setEphemeral(true).queue();
        }


    }

    public static void sendMessage(User user, String content) {
        user.openPrivateChannel()
                .flatMap(channel -> channel.sendMessage(content))
                .queue();
    }

    public static void sendEmbed(User user, EmbedBuilder content) {
        user.openPrivateChannel()
                .flatMap(channel -> channel.sendMessageEmbeds(content.build()))
                .queue();
    }
/*
    @Override
    public void onMessageReceived(@NotNull MessageReceivedEvent event)
    {
        String message = event.getMessage().getContentRaw();
        if(message.length() >= 7)
        {
            if(message.substring(0,7).equals("?broker"))
            {

                if(event.getMessage().getMember().getRoles().contains(event.getGuild().getRoleById("995363982963658802")))
                {
                    message = message.substring(7);
                    event.getChannel().sendMessage(message).queue();
                    System.out.println(message);
                } else {
                    event.getChannel().sendMessage("The Trader role is required to use the Broker bot!").queue();
                }

            }
        }

    }

*/

}
