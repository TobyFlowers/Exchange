package main.sql;

import main.Broker;

import java.sql.*;
import java.util.UUID;

public class OrdersSQL {
    private static Connection connection;

    public static void putBuy(String ticker, String traderId, double sharePrice, int shares, String uniqueID) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("INSERT INTO " + ticker.toLowerCase() + "_buy(traderId, transactionId, shareValue, numShares, commission) VALUES (?, ?, ?, ?, ?)");
        statement.setString(1,traderId);
        statement.setString(2,uniqueID);
        statement.setDouble(3,sharePrice);
        statement.setInt(4, shares);
        statement.setDouble(5, BrokerSQL.getCommission(traderId));

        statement.executeUpdate();
        closeConnection();

        recordOrder(traderId, uniqueID, shares, "buy", ticker);
    }

    public static void putSell(String ticker, String traderId, double sharePrice, int shares, String uniqueID) throws SQLException {

        openConnection();

        PreparedStatement statement = connection.prepareStatement("INSERT INTO " + ticker.toLowerCase() + "_sell(traderId, transactionId, shareValue, numShares) VALUES (?, ?, ?, ?)");
        statement.setString(1,traderId);
        statement.setString(2,uniqueID);
        statement.setDouble(3,sharePrice);
        statement.setInt(4, shares);
        statement.executeUpdate();
        closeConnection();
        recordOrder(traderId, uniqueID, shares, "sell", ticker);

    }

    public static boolean removeBuy(String ticker, String orderID, String traderID) throws SQLException {
        //only allowed on weekdays
        //check if ticker exists
        if(tableExist(ticker + "_buy"))
        {
            //check if order ID exists
            if(orderExists(orderID, ticker + "_buy"))
            {
                // check if whoever made the order with the order id is the sender (traderID)
                if(getTraderFromOrder(orderID, ticker + "_buy").equals(traderID))
                {

                    double value = StocksSQL.getPrice(ticker) * OrdersSQL.getTotalSharesInOrder(orderID);
                    double totalCom = value * 0.1;
                    if(totalCom > 100000)
                    {
                        totalCom = 100000;
                    }

                    BrokerSQL.deposit(traderID,value + totalCom,"**CANCELLED ORDER DEPOSIT**");

                    //remove order
                    openConnection();
                    PreparedStatement statement = connection.prepareStatement("DELETE FROM " + ticker + "_buy WHERE transactionId=\"" + orderID + "\"");
                    statement.executeUpdate();
                    closeConnection();
                    removeRecordFromOrderDatabase(orderID);
                    return true;
                }
            }
        }

        return false;
    }

    private static double getTotalSharesInOrder(String orderID) throws SQLException {
        double shares = 0;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT numShares FROM orders WHERE transactionId=\"" + orderID + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            shares = r.getInt("numShares");
        }

        return shares;
    }

    public static boolean removeSell(String ticker, String orderID, String traderID) throws SQLException {
        //only allowed on weekdays
        //check if ticker exists
        if(tableExist(ticker + "_sell"))
        {
            //check if order ID exists
            if(orderExists(orderID, ticker + "_sell"))
            {
                // check if whoever made the order with the order id is the sender (traderID)
                if(getTraderFromOrder(orderID, ticker + "_sell").equals(traderID))
                {
                    //remove order
                    openConnection();

                    int shares = 0;//get number of shares in order
                    PreparedStatement getShares = connection.prepareStatement("SELECT numShares FROM orders WHERE transactionId=\"" + orderID + "\"");
                    ResultSet results = getShares.executeQuery();
                    while(results.next())
                    {
                        shares = results.getInt("numShares");
                    }

                    System.out.println("#shares" + shares);

                    PreparedStatement statement = connection.prepareStatement("DELETE FROM " + ticker + "_sell WHERE transactionId=\"" + orderID + "\"");
                    statement.executeUpdate();

                    closeConnection();
                    BrokerSQL.giveShares(ticker, shares, traderID);
                    removeRecordFromOrderDatabase(orderID);
                    return true;
                }
            }
        }
        return false;

    }

    public static String getTraderFromOrder(String orderID, String tableName) throws SQLException {
        String result = "";

        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT traderId FROM " + tableName + " WHERE transactionId=\"" + orderID + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            result = r.getString("traderId");
        }

        return result;

    }

    public static boolean orderExists(String orderID, String tableName) throws SQLException {
        boolean result = false;

        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + tableName + " WHERE transactionId=\"" + orderID + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            result = true;
        }

        return result;

    }

    public static boolean tableExist(String name) throws SQLException {

        boolean result = false;

        openConnection();
        PreparedStatement statement = connection.prepareStatement("SHOW TABLES LIKE \"" + name + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            result = true;
        }

        return result;
    }

    public static ResultSet getOrders(String traderID) throws SQLException {
        openConnection();
        PreparedStatement getBuyOrders = connection.prepareStatement("SELECT * FROM orders WHERE traderId=\"" + traderID + "\"");
        ResultSet outSet = getBuyOrders.executeQuery();
        closeConnection();

        return outSet;
    }

    public static String uniqueID(){

        String r = UUID.randomUUID().toString().substring(24);
        return r;

    }

    public static void createBuyTable(String ticker) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("CREATE TABLE " + ticker + "_buy" + " ( traderId varchar(19), transactionId varchar(12), shareValue double(20,2), numShares int, commission double(3,2), PRIMARY KEY(transactionId))");
        statement.executeUpdate();
        closeConnection();

    }

    public static void createSellTable(String ticker) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("CREATE TABLE " + ticker + "_sell" + " ( traderId varchar(19), transactionId varchar(12), shareValue double(20,2), numShares int, PRIMARY KEY(transactionId))");
        statement.executeUpdate();
        closeConnection();
    }

    public static void recordOrder(String traderId, String transactionId, int numShares, String orderType, String ticker) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("INSERT INTO orders(traderId, transactionId, numShares, orderType, ticker) VALUES(?, ?, ?, ?, ?)");
        statement.setString(1, traderId);
        statement.setString(2, transactionId);
        statement.setInt(3, numShares);
        statement.setString(4, orderType);
        statement.setString(5, ticker);

        statement.executeUpdate();
        closeConnection();
    }


    public static void removeRecordFromOrderDatabase(String transactionId) throws SQLException{
        openConnection();
        PreparedStatement statement = connection.prepareStatement("DELETE FROM orders WHERE transactionId=\"" + transactionId + "\"");
        statement.executeUpdate();
        closeConnection();
    }
    public static void openConnection() throws SQLException {
        connection = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/orders",
                "root", "");

    }

    public static void closeConnection() throws SQLException
    {
        connection.close();
    }

}
