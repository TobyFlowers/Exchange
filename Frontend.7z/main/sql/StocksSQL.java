package main.sql;

import main.Broker;
import main.listeners.BrokerEvents;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Channel;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.Event;

import java.awt.*;
import java.sql.*;

public class StocksSQL {
    private static Connection connection;


    public static boolean buy(String ticker, String ID, int amount, User sender) throws SQLException {

        boolean hasEnoughMoney = false;
        boolean adaquateSharesForSale = false;
        boolean stockExists = stockExists(ticker);
        double rate = BrokerSQL.getCommission(ID);
        double commission = 0.00;
        String uniqueID = OrdersSQL.uniqueID();

        if(stockExists){

            if(BrokerSQL.isFrozen(ticker.toLowerCase()))
            {
                return false;
            }

            System.out.println("amount: " + amount + " available:" + getAvailableShares(ticker));
            if(amount <= getTotalShares(ticker))
            {
                adaquateSharesForSale = true;
            }
            System.out.println("total price:" + (getPrice(ticker) * (double) amount) + " balance: " +  BrokerSQL.nf.format(BrokerSQL.rawBalance(ID)));
            if((getPrice(ticker) * (double) amount + (rate * (getPrice(ticker) * ((double) amount)))) <= BrokerSQL.rawBalance(ID)){
                hasEnoughMoney = true;
            }

            if(hasEnoughMoney && adaquateSharesForSale)
            {


                BrokerSQL.withdraw(ID, getPrice(ticker) * ((double) amount));
                /*openConnection();

                PreparedStatement statement2 = connection.prepareStatement("UPDATE stocks SET TotalAvailable=TotalAvailable-" + amount + " where Ticker=\"" + ticker + "\"");
                statement2.executeQuery();
                closeConnection();*/

                commission = (rate * (getPrice(ticker) * ((double) amount)));
                if(commission > 100000)
                {
                    commission = 100000;
                }

                BrokerEvents.logChannel.sendMessage(String.format("**ID**: " + ID + "\nBUY: x" + amount + " shares of " + ticker.toUpperCase()) + "\nTotal Value of shares: " + BrokerSQL.nf.format(getPrice(ticker) * ((double) amount))
                + " COMMISSION PAYED: " + BrokerSQL.nf.format((rate * (getPrice(ticker) * ((double) amount)))) + "\nTransaction ID: " +uniqueID).queue();

                //String DM = String.format("**ID**: " + ID + "\nBUY: x" + amount + " shares of " + ticker.toUpperCase()) + "\nTotal Value of shares: " + BrokerSQL.nf.format(getPrice(ticker) * ((double) amount))
                  //      + " COMMISSION PAYED: " + BrokerSQL.nf.format(commission) + "\nTransaction ID: " +uniqueID;
                EmbedBuilder embed = new EmbedBuilder();
                embed.setTitle("YOUR BUY ORDER");
                embed.addField("Company:", ticker.toUpperCase(), false);
                embed.addField("Amount:", String.valueOf(amount), false);
                embed.addField("Value:", BrokerSQL.nf.format((getPrice(ticker) * ((double) amount))), false);
                embed.addField("Transaction ID:", uniqueID, false);
                embed.addField("Account ID:", ID, false);
                embed.setColor(new Color(0xbb8fce));
                embed.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
                embed.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");

                BrokerEvents.sendEmbed(sender, embed);


                BrokerSQL.withdraw(ID, commission);
                OrdersSQL.putBuy(ticker, ID, getPrice(ticker),amount, uniqueID);

                EmbedBuilder eb = new EmbedBuilder();
                eb.setTitle("NEW BUY ORDER");
                eb.addField("Company:", ticker.toUpperCase(), false);
                eb.addField("Amount:", String.valueOf(amount), false);
                eb.addField("Value:", BrokerSQL.nf.format((getPrice(ticker) * ((double) amount))), false);
                eb.setColor(new Color(0xbb8fce));
                eb.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                TextChannel channel = BrokerEvents.publicTradeChannel;
                channel.sendMessageEmbeds(eb.build()).queue();

                return true;
            }

        }

        return false;

    }


    public static EmbedBuilder getInfoEmbed(String ticker) throws SQLException {
        EmbedBuilder eb = new EmbedBuilder();
        if(stockExists(ticker))
        {

            eb.setTitle(ticker.toUpperCase());
            double pchange = BrokerSQL.getPercentChange(ticker);
            double percentOnMarket = BrokerSQL.getPercentOnMarket(ticker);
            if(pchange < 0)
            {
                eb.addField("Price", BrokerSQL.nf.format(getPrice(ticker)) + " (" + BrokerSQL.pf.format(BrokerSQL.getPercentChange(ticker)) + ")", true);

            } else {
                eb.addField("Price", BrokerSQL.nf.format(getPrice(ticker)) + " (+" + BrokerSQL.pf.format(BrokerSQL.getPercentChange(ticker)) + ")", true);

            }
            eb.setDescription(BrokerSQL.getFull(ticker) + "\n" + BrokerSQL.pf.format(percentOnMarket) + " on market.");
            eb.addField("Available Shares", getAvailableShares(ticker) + "/" +  getTotalShares(ticker), true);
            eb.setColor(new Color(0xbb8fce));
            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

        }else{
            eb.setTitle(ticker.toUpperCase());
            eb.setColor(Color.RED);
            eb.setDescription("This ticker does not exist!");
            eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
            eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");

        }
        return eb;
    }

    public static boolean sell(String ticker, String ID, int amount, User sender) throws SQLException {
        boolean stockExists = stockExists(ticker);
        int sharesHeld = 0;
        String uniqueID = OrdersSQL.uniqueID();


        if(stockExists)
        {

            if(BrokerSQL.isFrozen(ticker.toLowerCase()))
            {
                return false;
            }

            openConnection();

            PreparedStatement statement = connection.prepareStatement("SELECT " + ticker + " FROM exchange WHERE id=" + ID);
            ResultSet r = statement.executeQuery();
            closeConnection();

            while(r.next())
            {
                sharesHeld = r.getInt(ticker);
            }

            if(amount <= sharesHeld)
            {
                openConnection();
                //remove shares from player
                PreparedStatement statement2 = connection.prepareStatement("UPDATE exchange SET " + ticker + "=" + ticker + "-" + amount + " where id=\"" + ID + "\"");
                statement2.executeUpdate();
                //add shares back to available shares
                //PreparedStatement statement3 = connection.prepareStatement("UPDATE stocks SET TotalAvailable=TotalAvailable+" + amount + " where Ticker=\"" + ticker + "\"");
                //statement3.executeUpdate();

                closeConnection();
                BrokerEvents.logChannel.sendMessage("**ID**: " + ID+ "\nSELL: x" + amount + " shares of " + ticker.toUpperCase() + "\nTotal Value: " + BrokerSQL.nf.format(getPrice(ticker) * ((double) amount))
                + "\nTransaction ID: " + uniqueID).queue();

               /* String DM = "**ID**: " + ID+ "\nSELL: x" + amount + " shares of " + ticker.toUpperCase() + "\nTotal Value: " + BrokerSQL.nf.format(getPrice(ticker) * ((double) amount))
                        + "\nTransaction ID: " + uniqueID;
                BrokerEvents.sendMessage(sender, DM);*/

                EmbedBuilder embed = new EmbedBuilder();
                embed.setTitle("YOUR SELL ORDER");
                embed.addField("Company:", ticker.toUpperCase(), false);
                embed.addField("Amount:", String.valueOf(amount), false);
                embed.addField("Value:", BrokerSQL.nf.format((getPrice(ticker) * ((double) amount))), false);
                embed.addField("Transaction ID:", uniqueID, false);
                embed.addField("Account ID:", ID, false);
                embed.setColor(new Color(0xbb8fce));
                embed.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
                embed.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");

                BrokerEvents.sendEmbed(sender, embed);

                OrdersSQL.putSell(ticker, ID, getPrice(ticker), amount, uniqueID);

                EmbedBuilder eb = new EmbedBuilder();
                eb.setTitle("NEW SELL ORDER");
                eb.addField("Company:", ticker.toUpperCase(), false);
                eb.addField("Amount:", String.valueOf(amount), false);
                eb.addField("Value:", BrokerSQL.nf.format((getPrice(ticker) * ((double) amount))), false);
                eb.setColor(new Color(0xbb8fce));
                eb.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
                eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
                TextChannel channel = BrokerEvents.publicTradeChannel;
                channel.sendMessageEmbeds(eb.build()).queue();

                return true;
            }




        }


        return false;
    }

    public static boolean stockExists(String ticker) throws SQLException {
        boolean out = false;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SHOW COLUMNS FROM exchange LIKE \"" + ticker +"\"");
        ResultSet r = statement.executeQuery();

        if(r.next())
        {
            out = true;
        }else{
            out = false;
        }
        closeConnection();
        return out;
    }

    public static void addStock(String ticker, String fullName, double price, int amount, int total) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("""
            INSERT INTO stocks(Ticker,full,Price,lastPrice,TotalAvailable,TotalShares,frozen, TotalAll)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """);
        statement.setString(1, ticker);
        statement.setString(2, fullName);
        statement.setDouble(3, price);
        statement.setDouble(4, price);
        statement.setInt(5, amount);
        statement.setInt(6, amount);
        statement.setBoolean(7, false);
        statement.setInt(8, total);



        statement.executeUpdate();

        PreparedStatement statement2 =  connection.prepareStatement("ALTER TABLE exchange ADD COLUMN " + ticker + " INT DEFAULT 0");
        statement2.executeUpdate();

        closeConnection();



    }

    public static double getPrice(String ticker) throws SQLException{
        openConnection();
        double r = 0.00;
        PreparedStatement statement = connection.prepareStatement("SELECT Price FROM stocks WHERE Ticker=\"" + ticker+"\"");

        ResultSet results = statement.executeQuery();
        while(results.next()){
            r = results.getDouble("Price");
        }
        closeConnection();

        return r;
    }

    public static int getAvailableShares(String ticker) throws SQLException {
        openConnection();
        int r = 0;
        PreparedStatement statement = connection.prepareStatement("SELECT TotalAvailable FROM stocks WHERE Ticker=\"" + ticker + "\"");

        ResultSet results = statement.executeQuery();
        while(results.next()){
            r = results.getInt("TotalAvailable");
        }
        closeConnection();

        return r;
    }

    public static int getTotalShares(String ticker) throws SQLException {
        openConnection();
        int r = 0;
        PreparedStatement statement = connection.prepareStatement("SELECT TotalShares FROM stocks WHERE Ticker=\"" + ticker + "\"");

        ResultSet results = statement.executeQuery();
        while(results.next()){
            r = results.getInt("TotalShares");
        }
        closeConnection();

        return r;
    }

    public static void openConnection() throws SQLException {
        connection = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/broker",
                "root", "");

    }

    public static void closeConnection() throws SQLException
    {
        connection.close();
    }

    public static EmbedBuilder getCompanies() throws SQLException {
        EmbedBuilder eb = new EmbedBuilder();
        eb.setColor(new Color(0xbb8fce));
        eb.setTitle("Companies");
        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT Ticker,full FROM stocks");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            eb.addField("$" + r.getString("Ticker"), r.getString("full"), true);
        }

        return eb;

    }

    public static double updatePriceFromValuation(double valuation, int shares, String ticker) throws SQLException {
        double pps = valuation / ((double) shares);
        double oldPrice = getPrice(ticker.toLowerCase());
        double quarterDiff = 0.25*(pps - oldPrice);
        double price = oldPrice + quarterDiff;

        openConnection();
        PreparedStatement statement = connection.prepareStatement("UPDATE stocks set Price=" + price + " where Ticker=\"" + ticker.toLowerCase() + "\"");
        statement.executeUpdate();
        closeConnection();

        EmbedBuilder eb = new EmbedBuilder();
        eb.setTitle("UPDATED PRICE FOR STOCK");
        eb.addField("Ticker:", ticker.toUpperCase(), false);
        eb.addField("Old Price:", BrokerSQL.nf.format(oldPrice), false);
        eb.addField("New Price:", BrokerSQL.nf.format(price), false);
        eb.setColor(new Color(0xbb8fce));
        TextChannel channel = BrokerEvents.logChannel;
        channel.sendMessageEmbeds(eb.build()).queue();

        return price;

    }
}
