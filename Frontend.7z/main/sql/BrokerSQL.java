package main.sql;

import main.listeners.BrokerEvents;
import net.dv8tion.jda.api.EmbedBuilder;

import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class BrokerSQL {
    private static Connection connection;
    public static NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
    static DecimalFormat pf = new DecimalFormat("##.##%");




    public static int getNumberColumns(String table) throws SQLException {
        int r = 0;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name=\"" + table + "\"");
        ResultSet results = statement.executeQuery();
        while(results.next())
        {
            r = results.getInt("COUNT(*)");
        }
        closeConnection();
        return r;
    }

    public static boolean isRegistered(String ID) throws SQLException {
        boolean exists = false;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM exchange WHERE id=\"" + ID + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            exists = true;
        }
        return exists;
    }
    public static boolean registerUser(String ID, String IGN) throws SQLException {
            if(isRegistered(ID)){
                return false;
            } else {
            openConnection();

            PreparedStatement statement = connection.prepareStatement("""
                  INSERT INTO exchange(id, balance, ign, commission) 
                  VALUES (?, ?, ?, ?)
            """);
            statement.setString(1, ID);
            statement.setDouble(2,0);
            statement.setString(3, IGN);
            statement.setDouble(4, 0.1);;
            statement.executeUpdate();


            closeConnection();
            }




        return true;
    }

    public static double getCommission(String ID) throws SQLException
    {
        double rate = 0.1;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT commission FROM exchange WHERE ID=\"" + ID + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            r.getDouble("commission");
        }
        if(ID.equals("933291468364345364"))
        {
            rate =0.06;
        }

        return rate;
    }

    public static boolean userIsFrozen(String ID) throws SQLException {
        Boolean r = false;

        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT frozen FROM exchange WHERE id=\"" + ID + "\"");
        ResultSet resultSet = statement.executeQuery();
        closeConnection();

        while(resultSet.next())
        {
            r = resultSet.getBoolean("frozen");
        }

        return r;
    }

    public static EmbedBuilder getPortfolio(String ID) throws SQLException {
        EmbedBuilder eb = new EmbedBuilder();
        eb.setTitle("Portfolio");
        eb.setColor(new Color(0xbb8fce));
        eb.addField("Account Number | ",ID, false);
        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
        eb.setThumbnail("https://media.discordapp.net/attachments/856746001029136384/1008250867465588846/audit.png?size=128");
        openConnection();

        PreparedStatement statement = connection.prepareStatement("SELECT * FROM exchange WHERE id=" + ID);
        ResultSet result = statement.executeQuery();

        closeConnection();
        ResultSetMetaData rmsd = result.getMetaData();
        boolean isEmpty = true;
        while(result.next())
        {
            if(getNumberColumns("exchange") > 5)
            {
                for(int i = 6; i <= getNumberColumns("exchange"); i++)
                {
                    if(result.getInt(i) > 0)
                    {
                        double totalPrice = 0;
                        totalPrice = StocksSQL.getPrice(rmsd.getColumnLabel(i)) * (double) result.getInt(i);
                        eb.addField(rmsd.getColumnLabel(i).toUpperCase() + " | ", String.valueOf(result.getInt(i)), false);
                        isEmpty = false;
                    }
                }
            }

        }
        if(isEmpty)
        {
            eb.setDescription("You do not have any stocks. \nCheck /orders.");
        }

        return eb;

    }

    public static String getBalance(String ID) throws SQLException {


        double r = rawBalance(ID);
        return nf.format(r);

    }

    public static boolean deposit(String ID, double amount) throws SQLException {

        openConnection();

        PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET balance =" + (rawBalance(ID) + amount) + "WHERE id=" + ID);
        statement.executeUpdate();
        closeConnection();

        BrokerEvents.depositWithdrawChannel.sendMessage(String.format(nf.format(amount) + " deposited into account ID: " + ID + " **ORDER WITHDRAWAL**")).queue();

        return true;
    }

    public static boolean withdraw(String ID, double amount) throws SQLException {


        if((rawBalance(ID) - amount) < 0)
        {
            return false;
        } else {
            openConnection();

            PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET balance =" + (rawBalance(ID) - amount) + "WHERE id=" + ID);
            statement.executeUpdate();
            closeConnection();
        }

        BrokerEvents.depositWithdrawChannel.sendMessage(String.format(nf.format(amount) + " withdrawn from account ID: " + ID+ " **ORDER WITHDRAWAL**")).queue();


        return true;
    }

    public static double rawBalance(String ID) throws SQLException {
        openConnection();
        double r = 0.00;
        PreparedStatement statement = connection.prepareStatement("SELECT balance FROM exchange WHERE id=" + ID);

        ResultSet results = statement.executeQuery();
        while(results.next()){
            r = results.getDouble("balance");
        }
        closeConnection();

        return r;
    }

    public static boolean deposit(String ID, double amount, String extra) throws SQLException {

        openConnection();

        PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET balance =" + (rawBalance(ID) + amount) + "WHERE id=" + ID);
        statement.executeUpdate();
        closeConnection();

        BrokerEvents.depositWithdrawChannel.sendMessage(String.format(nf.format(amount) + " deposited into account ID: " + ID + " " + extra)).queue();

        return true;
    }

    public static boolean withdraw(String ID, double amount, String extra) throws SQLException {


        if((rawBalance(ID) - amount) < 0)
        {
            return false;
        } else {
            openConnection();

            PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET balance =" + (rawBalance(ID) - amount) + "WHERE id=" + ID);
            statement.executeUpdate();
            closeConnection();
        }

        BrokerEvents.depositWithdrawChannel.sendMessage(String.format(nf.format(amount) + " withdrawn from account ID: " + ID+ " " + extra)).queue();


        return true;
    }



    public static void openConnection() throws SQLException {
        connection = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/broker",
                "root", "");

    }

    public static void closeConnection() throws SQLException
    {
        connection.close();
    }

    public static double getPercentOnMarket(String ticker) throws SQLException {
        int shares = StocksSQL.getTotalShares(ticker);
        int allShares = shares;
        openConnection();
        PreparedStatement getLastPrice = connection.prepareStatement("SELECT TotalAll FROM stocks WHERE Ticker=\"" + ticker.toLowerCase() + "\"");
        ResultSet r = getLastPrice.executeQuery();
        closeConnection();

        while(r.next())
        {
            allShares = r.getInt("TotalAll");
        }

        double percent = (double) shares / (double) allShares;
        return percent;
    }

    public static double getPercentChange(String ticker) throws SQLException {
        double lastPrice = 0;
        double price = StocksSQL.getPrice(ticker.toLowerCase());

        openConnection();
        PreparedStatement getLastPrice = connection.prepareStatement("SELECT lastPrice FROM stocks WHERE Ticker=\"" + ticker.toLowerCase() + "\"");
        ResultSet r = getLastPrice.executeQuery();
        closeConnection();

        while(r.next())
        {
            lastPrice = r.getDouble("lastPrice");
        }

        double percent = (price-lastPrice)/(Math.abs(lastPrice));
        return percent;
    }

    public static boolean freezeStock(String ticker) throws SQLException
    {
        if(StocksSQL.stockExists(ticker.toLowerCase()))
        {
            openConnection();
            PreparedStatement freeze = connection.prepareStatement("UPDATE stocks SET frozen=TRUE WHERE Ticker=\"" + ticker.toLowerCase() + "\"");
            freeze.executeUpdate();
            closeConnection();
            return true;
        }
        return false;
    }

    public static boolean unfreezeStock(String ticker) throws SQLException
    {
        if(StocksSQL.stockExists(ticker.toLowerCase()))
        {
            openConnection();
            PreparedStatement freeze = connection.prepareStatement("UPDATE stocks SET frozen=FALSE WHERE Ticker=\"" + ticker.toLowerCase() + "\"");
            freeze.executeUpdate();
            closeConnection();
            return true;
        }
        return false;
    }

    public static boolean isFrozen(String ticker) throws SQLException
    {

            boolean frozen = true;
            openConnection();
            PreparedStatement frozenStatement = connection.prepareStatement("SELECT frozen FROM stocks WHERE ticker=\"" + ticker.toLowerCase() + "\"");
            ResultSet r = frozenStatement.executeQuery();
            closeConnection();
            while(r.next())
            {
                frozen = r.getBoolean("frozen");
            }

            return frozen;

    }

    public static void giveShares(String ticker, int shares, String traderID) throws SQLException {
        String ex = "437238100616282112";
        openConnection();
        PreparedStatement returnShares = connection.prepareStatement("UPDATE exchange SET " + ticker.toLowerCase() + "=" + ticker.toLowerCase() + "+" + shares + " WHERE id=\"" + traderID + "\"");
        PreparedStatement takeExchange = connection.prepareStatement("UPDATE exchange SET " + ticker.toLowerCase() + "=" + ticker.toLowerCase() + "-" + shares + " WHERE id=\"" + ex + "\"");
        takeExchange.executeUpdate();

        returnShares.executeUpdate();
        closeConnection();
    }

    public static void takeShares(String ticker, int amount, String userId) throws SQLException {
        String ex = "437238100616282112";

        openConnection();
        PreparedStatement returnShares = connection.prepareStatement("UPDATE exchange SET " + ticker.toLowerCase() + "=" + ticker.toLowerCase() + "-" + amount + " WHERE id=\"" + userId + "\"");
        returnShares.executeUpdate();
        /*
        PreparedStatement increaseTotalAvailable = connection.prepareStatement("UPDATE stocks SET TotalAvailable=TotalAvailable-" + amount + " where Ticker=\"" + ticker + "\"");
        increaseTotalAvailable.executeUpdate();*/

        //give margaret shares
        PreparedStatement giveMargaret = connection.prepareStatement("UPDATE exchange SET " + ticker.toLowerCase() + "=" + ticker.toLowerCase() + "+" + amount + " WHERE id=\"" + "437238100616282112" + "\"");
        giveMargaret.executeUpdate();
        closeConnection();
    }

    public static String getFull(String ticker) throws SQLException {
        String name = "";
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT full FROM stocks WHERE ticker=\"" + ticker.toLowerCase() + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            name = r.getString("full");
        }

        return name;
    }

    public static EmbedBuilder getShareholders(String ticker) throws SQLException {

        EmbedBuilder eb = new EmbedBuilder();
        eb.setColor(new Color(0xbb8fce));
        eb.setTitle("Shareholders");
        eb.setThumbnail("https://cdn.discordapp.com/icons/853415257565560912/85481dbeeaa895a85d173fc01ef455fd.png?size=128");
        eb.setFooter("All investing involves risk.", "https://cdn.discordapp.com/emojis/704812546871525406.png?size=56&quality=lossless");
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT id,ign," + ticker + " FROM exchange WHERE " + ticker + ">0");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            eb.addField(r.getString("ign"), r.getString("id") + "\nShares: " + r.getInt(ticker), true);
        }

        return eb;
    }

    public static int getUsersShares(String ticker, String user) throws SQLException {
        int shares = 0;
        openConnection();
        PreparedStatement statement = connection.prepareStatement("SELECT " + ticker +  " FROM exchange WHERE id=\"" + user + "\"");
        ResultSet r = statement.executeQuery();
        closeConnection();

        while(r.next())
        {
            shares = r.getInt(ticker);
        }

        return shares;
    }
    public static void freezeUser(String id) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET frozen=TRUE WHERE id=\"" + id + "\"");
        statement.executeUpdate();
        closeConnection();
    }

    public static void unfreezeUser(String id) throws SQLException {
        openConnection();
        PreparedStatement statement = connection.prepareStatement("UPDATE exchange SET frozen=FALSE WHERE id=\"" + id + "\"");
        statement.executeUpdate();
        closeConnection();
    }



}
