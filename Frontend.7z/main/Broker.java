package main;
import main.listeners.BrokerEvents;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.requests.GatewayIntent;

import javax.security.auth.login.LoginException;

public class Broker {

    public static void main(String... args) throws LoginException, InterruptedException {
        JDA bot = JDABuilder.createDefault("OTk4NzcxNzA4NDIzMDU3NDA4.GRZwnW.mlS_u16p5uKvduGUL51YU5BHAt0LrMwHZL_v48").enableIntents(GatewayIntent.MESSAGE_CONTENT).setActivity(Activity.playing("with stocks!")).addEventListeners(new BrokerEvents()).build().awaitReady();
        Guild guild = bot.getGuildById("853415257565560912");
        if(guild != null)
        {
            guild.upsertCommand("help", "Shows what all the commands do").queue();
            guild.upsertCommand("balance", "Shows your balance").queue();
            guild.upsertCommand("portfolio","Displays your portfolio").queue();
            guild.upsertCommand("info", "Displays information on a stock ticker")
                    .addOption(OptionType.STRING, "ticker", "Ticker Name", true)
                    .queue();
            guild.upsertCommand("sell", "Sell your shares")
                    .addOptions(
                            new OptionData(OptionType.STRING, "ticker", "Ticker Name", true),
                            new OptionData(OptionType.INTEGER, "amount", "Number of Shares", true).setRequiredRange(1, Integer.MAX_VALUE)

                    )
                    .queue();
            guild.upsertCommand("buy", "Buy shares")
                    .addOptions(
                            new OptionData(OptionType.STRING, "ticker", "Ticker Name", true),
                            new OptionData(OptionType.INTEGER, "amount", "Number of Shares", true).setRequiredRange(1, Integer.MAX_VALUE)

                    )
                    .queue();

            guild.upsertCommand("withdraw","Withdraws money from an account")
                    .addOptions(
                            new OptionData(OptionType.STRING, "id", "Discord ID", true),
                            new OptionData(OptionType.NUMBER, "amount", "Amount of money", true)
                    )
                    .queue();

            guild.upsertCommand("deposit","Deposits money into an account")
                    .addOptions(
                            new OptionData(OptionType.STRING, "id", "Discord ID", true),
                            new OptionData(OptionType.NUMBER, "amount", "Amount of money", true)
                    )
                    .queue();

            guild.upsertCommand("register","Create a trading account")
                    .addOptions(
                            new OptionData(OptionType.STRING, "id", "Discord ID", true),
                            new OptionData(OptionType.STRING, "ign", "In-game name", true)
                    )
                    .queue();

            guild.upsertCommand("create", "Create a stock ticker")
                    .addOptions(
                        new OptionData(OptionType.STRING, "ticker", "Stock Ticker", true),
                            new OptionData(OptionType.STRING, "full", "Full Name", true),
                            new OptionData(OptionType.NUMBER, "price", "Opening Price", true).setRequiredRange(1, Integer.MAX_VALUE),
                        new OptionData(OptionType.INTEGER, "amount", "Number of shares public", true).setRequiredRange(1, Integer.MAX_VALUE),
                        new OptionData(OptionType.INTEGER, "total", "Number of shares overall", true).setRequiredRange(1, Integer.MAX_VALUE)

                    )
                    .queue();
            guild.upsertCommand("orders", "List your orders")
                    .queue();
            guild.upsertCommand("remove", "Remove an order")
                    .addOptions(
                            new OptionData(OptionType.STRING, "type", "Buy/Sell", true), //order type
                            new OptionData(OptionType.STRING, "ticker", "Stock Ticker", true), //ticker
                            new OptionData(OptionType.STRING, "id", "Transaction ID", true)  //transactionID
                    )
                    .queue();
            guild.upsertCommand("freeze", "Freeze the trading of a stock")
                    .addOption(OptionType.STRING, "ticker", "Stock ticker", true)
                    .queue();
            guild.upsertCommand("unfreeze", "Unfreeze the trading of a stock")
                    .addOption(OptionType.STRING, "ticker", "Stock ticker", true)
                    .queue();
            guild.upsertCommand("aportfolio", "Admin Portfolio")
                    .addOption(OptionType.STRING, "id", "User ID", true)
                    .queue();
            guild.upsertCommand("shareholders", "Admin Command for shareholders")
                    .addOption(OptionType.STRING, "ticker", "Stock Ticker", true)
                    .queue();
            guild.upsertCommand("companies", "Get companies list")
                    .queue();
            guild.upsertCommand("userfreeze", "Freeze a user from trading")
                    .addOption(OptionType.STRING, "id", "User ID", true)
                    .queue();
            guild.upsertCommand("userunfreeze", "Unfreeze a user from trading")
                    .addOption(OptionType.STRING, "id", "User ID", true)
                    .queue();
            guild.upsertCommand("grantshares", "Gives a user stocks")
                    .addOption(OptionType.STRING, "id","User ID",true)
                    .addOption(OptionType.STRING, "ticker","Stock Ticker",true)
                    .addOption(OptionType.INTEGER, "amount","Amount of shares",true)
                    .queue();
            guild.upsertCommand("takeshares", "Takes a user stocks")
                    .addOption(OptionType.STRING, "id","User ID",true)
                    .addOption(OptionType.STRING, "ticker","Stock Ticker",true)
                    .addOption(OptionType.INTEGER, "amount","Amount of shares",true)
                    .queue();
            guild.upsertCommand("abalance", "Admin command for user balance")
                    .addOption(OptionType.STRING, "id","User ID",true)
                    .queue();
            guild.upsertCommand("setvaluation", "Admin command for setting stock valuation")
                    .addOption(OptionType.STRING, "ticker","Stock Ticker",true)
                    .addOption(OptionType.NUMBER, "valuation", "Total Stock Valuation", true)
                    .addOption(OptionType.INTEGER, "shares","Total Number of shares private and public",true)
                    .queue();


        }

    }

}
