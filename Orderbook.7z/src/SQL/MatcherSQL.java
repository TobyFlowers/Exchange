package SQL;

import Orders.Order;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.ArrayList;

public class MatcherSQL {
    private static Connection brokerConnection;
    private static Connection orderConnection;


    public static String[] getTickers() throws SQLException {
        int numTickers = 0;
        openBrokerConnection();
        PreparedStatement count = brokerConnection.prepareStatement("SELECT COUNT(*) FROM stocks");
        ResultSet countSet = count.executeQuery();
        closeBrokerConnection();

        while(countSet.next())
        {
            numTickers = countSet.getInt("COUNT(*)");
        }

        String[] resultArray = new String[numTickers];

        openBrokerConnection();
        PreparedStatement tickers = brokerConnection.prepareStatement("SELECT Ticker FROM stocks");
        ResultSet tickerSet = tickers.executeQuery();
        closeBrokerConnection();

        int i = 0;
        while(tickerSet.next())
        {
            resultArray[i] = tickerSet.getString("Ticker");
            i++;
        }
        return  resultArray;


    }

    public static int getTotalBuy(String ticker) throws SQLException {
        int result = 0;
        openOrdersConnection();
        PreparedStatement buyCountStatement = orderConnection.prepareStatement("SELECT SUM(numShares) FROM " + ticker + "_buy");
        ResultSet r = buyCountStatement.executeQuery();
        closeOrdersConnection();
        while(r.next())
        {
            result = r.getInt("SUM(numShares)");
        }

        return result;

    }

    public static int getTotalSell(String ticker) throws SQLException {
        int result = 0;
        openOrdersConnection();
        PreparedStatement buyCountStatement = orderConnection.prepareStatement("SELECT SUM(numShares) FROM " + ticker + "_sell");
        ResultSet r = buyCountStatement.executeQuery();
        closeOrdersConnection();
        while(r.next())
        {
            result = r.getInt("SUM(numShares)");
        }

        return result;
    }

    public static double getPrice(String ticker) throws SQLException {

        double price = 0;

        openBrokerConnection();
        PreparedStatement getPrice = brokerConnection.prepareStatement("SELECT Price FROM stocks WHERE Ticker=\"" + ticker + "\"");
        ResultSet r = getPrice.executeQuery();
        closeBrokerConnection();

        while(r.next())
        {
            price = r.getDouble("Price");
        }

        return price;
    }

    public static ArrayList<Order> getBuyOrders(String ticker) throws SQLException {
        ArrayList<Order> buyOrders = new ArrayList<Order>();
        openOrdersConnection();
        PreparedStatement statement = orderConnection.prepareStatement("SELECT * FROM " + ticker + "_buy");
        ResultSet r = statement.executeQuery();
        closeOrdersConnection();

        while(r.next())
        {
            String transactionId = r.getString("transactionId");
            String traderId = r.getString("traderId");
            int numShares = r.getInt("numShares");
            double shareValue = r.getDouble("shareValue");
            buyOrders.add(new Order(transactionId, traderId, ticker, "buy", numShares, shareValue));

        }

        return buyOrders;
    }

    public static ArrayList<Order> getSellOrders(String ticker) throws SQLException {
        ArrayList<Order> buyOrders = new ArrayList<Order>();
        openOrdersConnection();
        PreparedStatement statement = orderConnection.prepareStatement("SELECT * FROM " + ticker + "_sell");
        ResultSet r = statement.executeQuery();
        closeOrdersConnection();

        while(r.next())
        {
            String transactionId = r.getString("transactionId");
            String traderId = r.getString("traderId");
            int numShares = r.getInt("numShares");
            double shareValue = r.getDouble("shareValue");
            buyOrders.add(new Order(transactionId, traderId, ticker, "sell", numShares, shareValue));

        }

        return buyOrders;
    }

    public static int getTotalShares(String ticker) throws SQLException {
        int out = 0;
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("SELECT TotalShares FROM stocks WHERE Ticker=\"" + ticker + "\"");
        ResultSet r = statement.executeQuery();
        closeBrokerConnection();

        while(r.next())
        {
            out = r.getInt("TotalShares");
        }

        return out;
    }

    public static int getTotalAvailable(String ticker) throws SQLException {
        int out = 0;
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("SELECT TotalAvailable FROM stocks WHERE Ticker=\"" + ticker + "\"");
        ResultSet r = statement.executeQuery();
        closeBrokerConnection();

        while(r.next())
        {
            out = r.getInt("TotalAvailable");
        }

        return out;
    }

    public static void logVolume(String ticker, int numBuy, int numSell) throws SQLException {
        openOrdersConnection();
        PreparedStatement statement = orderConnection.prepareStatement("INSERT INTO volumeLog(totalBuy,totalSell, ticker) VALUES(?,?,?)");
        statement.setInt(1,numBuy);
        statement.setInt(2,numSell);
        statement.setString(3,ticker);

        statement.executeUpdate();
        closeOrdersConnection();
    }
    public static void giveShares(String userID, String ticker, int shares, String transactionID) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE exchange SET " + ticker + "=" + ticker + "+" + shares + " WHERE id=\"" + userID + "\"");
        statement.executeUpdate();
        closeBrokerConnection();

        openOrdersConnection();
        PreparedStatement statement1 = orderConnection.prepareStatement("UPDATE orders SET numShares=numShares-" + shares + " WHERE transactionId=\"" + transactionID + "\"");
        statement1.executeUpdate();
        PreparedStatement statement2 = orderConnection.prepareStatement("UPDATE " + ticker + "_buy SET numShares=numShares-" + shares + " WHERE transactionId=\"" + transactionID + "\"");
        statement2.executeUpdate();
        closeOrdersConnection();
    }

    public static void takeShares(String userID, String ticker, int shares, String transactionId) throws SQLException {
       /* openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE exchange SET " + ticker + "=" + ticker + "-" + shares + " WHERE id=\"" + userID + "\"");
        statement.executeUpdate();
        closeBrokerConnection();*/

        openOrdersConnection();
        PreparedStatement statement1 = orderConnection.prepareStatement("UPDATE orders SET numShares=numShares-" + shares + " WHERE transactionId=\"" + transactionId + "\"");
        statement1.executeUpdate();
        PreparedStatement statement2 = orderConnection.prepareStatement("UPDATE " + ticker + "_sell SET numShares=numShares-" + shares + " WHERE transactionId=\"" + transactionId + "\"");
        statement2.executeUpdate();
        closeOrdersConnection();
    }

    public static void giveMoney(String userID, double amount) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE exchange SET balance=balance+" + amount + " WHERE id=\"" + userID + "\"");
        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void dropOrder(String transactionID, String ticker, String type) throws SQLException {
        openOrdersConnection();

        //drop from general order table
        PreparedStatement statement1 = orderConnection.prepareStatement("DELETE FROM orders WHERE transactionId=\"" + transactionID + "\"");
        statement1.executeUpdate();

        if(type.equals("buy"))
        {
            PreparedStatement statement2 = orderConnection.prepareStatement("DELETE FROM " + ticker + "_buy WHERE transactionId=\"" + transactionID + "\"");
            statement2.executeUpdate();


        }else{
            PreparedStatement statement3 = orderConnection.prepareStatement("DELETE FROM " + ticker + "_sell WHERE transactionId=\"" + transactionID + "\"");
            statement3.executeUpdate();


        }
        closeOrdersConnection();
    }

    public static void dropAll(String ticker) throws SQLException {//drop all orders from a ticker
        openOrdersConnection();
        PreparedStatement statement = orderConnection.prepareStatement("DELETE FROM orders WHERE ticker=\"" + ticker + "\"");
        PreparedStatement statement2 = orderConnection.prepareStatement("TRUNCATE TABLE " + ticker + "_buy");
        PreparedStatement statement3 = orderConnection.prepareStatement("TRUNCATE TABLE " + ticker + "_sell");
        statement.executeUpdate();
        statement2.executeUpdate();
        statement3.executeUpdate();
        closeOrdersConnection();
    }

    public static void setPrice(String ticker, double newPrice) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE stocks SET Price=" + newPrice + " WHERE Ticker=\"" + ticker + "\"");
        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void setLastPrice(String ticker, double originalPrice) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE stocks SET lastPrice=" + originalPrice + " WHERE Ticker=\"" + ticker + "\"");
        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void recordPrice(String priceDate, String ticker, double newPrice) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("""
                INSERT INTO priceRecord(date, ticker, price)
                VALUES(?,?,?)
                """);
        statement.setString(1,priceDate);
        statement.setString(2,ticker);
        statement.setDouble(3,newPrice);

        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void subtractAvailableShares(int amount, String ticker) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE stocks SET TotalAvailable=TotalAvailable-" + amount + " where Ticker=\"" + ticker + "\"");
        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void addAvailableShares(int amount, String ticker) throws SQLException {
        openBrokerConnection();
        PreparedStatement statement = brokerConnection.prepareStatement("UPDATE stocks SET TotalAvailable=TotalAvailable+" + amount + " where Ticker=\"" + ticker + "\"");
        statement.executeUpdate();
        closeBrokerConnection();
    }

    public static void openBrokerConnection() throws SQLException {
        brokerConnection = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/broker",
                "root", "");

    }

    public static void closeBrokerConnection() throws SQLException
    {
        brokerConnection.close();
    }

    public static void openOrdersConnection() throws SQLException {
        orderConnection = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/orders",
                "root", "");

    }

    public static void closeOrdersConnection() throws SQLException
    {
        orderConnection.close();
    }



}
