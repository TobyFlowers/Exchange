import Algorithms.FIFO;
import Algorithms.Pricer;
import Algorithms.ProRata;
import Orders.Order;
import Orders.Reimburse;
import SQL.MatcherSQL;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;

public class Main {

    public static void main(String... args) throws SQLException {

        String[] tickers = MatcherSQL.getTickers();
        for(String ticker : tickers)
        {
            int totalBuy = MatcherSQL.getTotalBuy(ticker);
            int totalSell = MatcherSQL.getTotalSell(ticker);
            int totalShares = MatcherSQL.getTotalShares(ticker);
            double stockPrice = MatcherSQL.getPrice(ticker);
            ProRata.match(ticker, totalBuy, totalSell);
            //now loop through and drop empty orders
            ArrayList<Order> buyOrders  = MatcherSQL.getBuyOrders(ticker);
            ArrayList<Order> sellOrders = MatcherSQL.getSellOrders(ticker);


            for(int i = 0; i < buyOrders.size(); i++)
            {
                System.out.println(buyOrders.get(i).getShares());
                if(buyOrders.get(i).getShares() == 0)
                {
                    MatcherSQL.dropOrder(buyOrders.get(i).getTransactionID(), ticker, "buy");

                }
            }

            for(int i = 0; i < sellOrders.size(); i++)
            {
                System.out.println(sellOrders.get(i).getShares());

                if(sellOrders.get(i).getShares() == 0)
                {
                    MatcherSQL.dropOrder(sellOrders.get(i).getTransactionID(), ticker, "sell");

                }
            }

            int totalBuy2 = MatcherSQL.getTotalBuy(ticker);
            int totalSell2 = MatcherSQL.getTotalSell(ticker);
            FIFO.match(ticker, totalBuy2, totalSell2);
            //now loop through and drop empty orders
            ArrayList<Order> buyOrders2  = MatcherSQL.getBuyOrders(ticker);
            ArrayList<Order> sellOrders2 = MatcherSQL.getSellOrders(ticker);

            for(int i = 0; i < buyOrders2.size(); i++)
            {
                System.out.println(buyOrders2.get(i).getShares());

                if(buyOrders2.get(i).getShares() == 0)
                {
                    MatcherSQL.dropOrder(buyOrders2.get(i).getTransactionID(), ticker, "buy");

                }
            }

            for(int i = 0; i < sellOrders2.size(); i++)
            {
                System.out.println(sellOrders2.get(i).getShares());

                if(sellOrders2.get(i).getShares() == 0)
                {
                    MatcherSQL.dropOrder(sellOrders2.get(i).getTransactionID(), ticker, "sell");

                }
            }

            Reimburse.endOrders(ticker, stockPrice);
            Pricer.updatePrice(ticker, stockPrice, totalShares, stockPrice, totalBuy, totalSell);

        }

    }

}
