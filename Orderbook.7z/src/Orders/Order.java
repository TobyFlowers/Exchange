package Orders;

public class Order {
    //priv variables
    private String transactionID;
    private String traderID;
    private String ticker;
    private String type;
    private int shares;
    private double value;
    //number of shares to be filled during pro-rata, #shares/totalShares (only on one side) -> rounded down
    private int toFill;
    public Order(String transactionID, String traderID, String ticker, String type, int shares, double value)
    {
        this.transactionID = transactionID;
        this.traderID = traderID;
        this.ticker = ticker;
        this.type = type;
        this.shares = shares;
        this.value = value;
    }

    public String getTransactionID()
    {
        return transactionID;
    }

    public String getTraderID()
    {
        return traderID;
    }

    public String getTicker()
    {
        return ticker;
    }

    public String getType()
    {
        return type;
    }

    public int getToFill(){
        return toFill;
    }

    public int getShares()
    {
        return shares;
    }

    public double getValue()
    {
        return value;
    }

    public void setTransactionID(String transactionID)
    {
        this.transactionID = transactionID;
    }

    public void setTraderID(String traderID)
    {
        this.traderID = traderID;
    }

    public void setTicker(String ticker)
    {
        this.ticker = ticker;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public void setShares(int shares)
    {
        this.shares = shares;
    }

    public void setValue(double value)
    {
        this.value = value;
    }

    public void setToFill(int toFill)
    {
        this.toFill = toFill;
    }
}
