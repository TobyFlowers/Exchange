package Orders;

import SQL.MatcherSQL;

import java.sql.SQLException;
import java.util.ArrayList;

public class Reimburse {



    public static void endOrders(String ticker, double originalPrice) throws SQLException {
        ArrayList<Order> buyOrders;
        ArrayList<Order> sellOrders;
        buyOrders = MatcherSQL.getBuyOrders(ticker);
        sellOrders = MatcherSQL.getSellOrders(ticker);

        for(int i = 0; i < buyOrders.size(); i++)
        {
            //send user back unused money
            MatcherSQL.giveMoney(buyOrders.get(i).getTraderID(), ( 0.05d * (double) buyOrders.get(i).getShares() * buyOrders.get(i).getValue() ) + (double) buyOrders.get(i).getShares() * buyOrders.get(i).getValue());
            //give user back unsold shares

        }

        for(int i = 0; i < sellOrders.size(); i++)
        {
            //send back user unsold shares
            MatcherSQL.giveShares(sellOrders.get(i).getTraderID(), ticker, sellOrders.get(i).getShares(), sellOrders.get(i).getTransactionID());
        }

        //drop all orders from the orders tables
        MatcherSQL.dropAll(ticker);

    }
}
