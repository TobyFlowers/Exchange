package Algorithms;

import Orders.Order;
import SQL.MatcherSQL;

import java.sql.SQLException;
import java.util.ArrayList;

public class FIFO {


    public static void match(String ticker, int totalBuy2, int totalSell2) throws SQLException {
        ArrayList<Order> buyOrders;
        ArrayList<Order> sellOrders;
        buyOrders = MatcherSQL.getBuyOrders(ticker);
        sellOrders = MatcherSQL.getSellOrders(ticker);


            for(int i = 0; i < buyOrders.size(); i++)
            {
                for(int j = 0; j < sellOrders.size(); j++)
                {

                    if(buyOrders.get(i).getShares() == 0)
                    {
                        j = sellOrders.size();
                    } else if (buyOrders.get(i).getShares() == sellOrders.get(j).getShares()) {
                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getShares();
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }

                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getShares();
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, buyOrders.get(i).getShares(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker, buyOrders.get(i).getShares(), sellOrders.get(j).getTransactionID());
                        MatcherSQL.giveMoney(sellOrders.get(j).getTraderID(), sellOrders.get(j).getValue() * (double) sellOrders.get(j).getShares());

                        buyOrders.get(i).setShares(0);
                        //give buyer shares
                        sellOrders.get(j).setShares(0);
                        //give seller money
                    } else if (buyOrders.get(i).getShares() > sellOrders.get(j).getShares()) {
                        int num = buyOrders.get(i).getShares() - sellOrders.get(j).getShares();
                        buyOrders.get(i).setShares(num);
                        //give buyer shares
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, sellOrders.get(j).getShares(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker, sellOrders.get(j).getShares(), sellOrders.get(j).getTransactionID());
                        MatcherSQL.giveMoney((sellOrders.get(j).getTraderID()), (double) sellOrders.get(j).getShares() * sellOrders.get(j).getValue());

                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = sellOrders.get(j).getShares();
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }


                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = sellOrders.get(j).getShares();
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }

                        sellOrders.get(j).setShares(0);
                        //give seller money(
                    } else /*more sell than buy*/{
                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getShares();
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }
                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getShares();
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }

                        sellOrders.get(j).setShares(sellOrders.get(j).getShares() - buyOrders.get(i).getShares());
                        //give seller money
                        MatcherSQL.giveMoney(sellOrders.get(j).getTraderID(), (double) buyOrders.get(i).getShares() * buyOrders.get(i).getValue());
                        //give buyer shares
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, buyOrders.get(i).getShares(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker, buyOrders.get(i).getShares(), sellOrders.get(j).getTransactionID());

                        buyOrders.get(i).setShares(0);
                        j = sellOrders.size();//get out of loop for this order because buy order has been filled

                    }

                }
            }


    }


}
