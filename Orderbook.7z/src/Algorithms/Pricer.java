package Algorithms;

import SQL.MatcherSQL;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;

public class Pricer {
    public static void updatePrice(String ticker, double originalPrice, double totalShares, double stockPrice, double totalBuy, double totalSell) throws SQLException {
        MatcherSQL.logVolume(ticker, (int) totalBuy, (int) totalSell);
        if(totalBuy > MatcherSQL.getTotalAvailable(ticker))
        {
            totalBuy = MatcherSQL.getTotalAvailable(ticker);
        }
        double newPrice = newPrice(originalPrice, totalShares, totalBuy, totalSell);
        //mysql set new price
        MatcherSQL.setLastPrice(ticker, originalPrice);
        MatcherSQL.setPrice(ticker, newPrice);
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = new Date();
        String priceDate = formatter.format(date);
        MatcherSQL.recordPrice(priceDate, ticker, newPrice);

    }

    private static double newPrice(double originalPrice, double totalShares, double totalBuy, double totalSell) {
        double newPrice = 0.00;
        String shares = String.valueOf(totalShares);


        double x = ((1000*(Math.abs(shares.length()))) * (totalBuy-totalSell))/(originalPrice * totalShares);
        double percent = Math.pow(Math.abs(x), 1/1.3)/100;
/*
        if(totalBuy == 0)
        {
            percent = 0;
        }*/

        if(x > 0)
        {

            newPrice = originalPrice + (originalPrice * percent);
        } else {
            if(percent < -99.99)
            {
                percent = -99.99;
            }
            newPrice = originalPrice - (originalPrice * percent);

        }
        return newPrice;


    }
}
