package Algorithms;

import Orders.Order;
import SQL.MatcherSQL;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;

public class ProRata {


    public static void match(String ticker, int totalBuy, int totalSell) throws SQLException {
        ArrayList<Order> buyOrders;
        ArrayList<Order> sellOrders;
        buyOrders = MatcherSQL.getBuyOrders(ticker);
        sellOrders = MatcherSQL.getSellOrders(ticker);

        for(int i = 0; i < buyOrders.size(); i++)
        {
            double percent = ((double) buyOrders.get(i).getShares())/(double) totalBuy;
            double numShares =  percent * totalSell;
            buyOrders.get(i).setToFill((int) numShares);
        }

        if(totalBuy > totalSell)
        {
            for(int i = 0; i < buyOrders.size(); i++)
            {
                for(int j = 0; j < sellOrders.size(); j++)
                {

                    if(buyOrders.get(i).getToFill() == 0)
                    {
                        j = sellOrders.size();
                    } else if (buyOrders.get(i).getToFill() == sellOrders.get(j).getShares()) {
                        int num = buyOrders.get(i).getToFill();
                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = num;
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }
                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = num;
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, buyOrders.get(i).getToFill(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.giveMoney(sellOrders.get(j).getTraderID(), (double) num * buyOrders.get(i).getValue());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker, buyOrders.get(i).getToFill(), sellOrders.get(j).getTransactionID());
                        buyOrders.get(i).setToFill(0);
                        //give buyer shares
                        sellOrders.get(j).setShares(0);
                        //give seller money
                        j = sellOrders.size();
                    } else if (buyOrders.get(i).getToFill() > sellOrders.get(j).getShares()) {
                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = sellOrders.get(j).getShares();
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }
                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = sellOrders.get(j).getShares();
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }
                        MatcherSQL.giveMoney(sellOrders.get(j).getTraderID(), (double)  sellOrders.get(j).getShares() * sellOrders.get(j).getValue());
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, sellOrders.get(j).getShares(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker,sellOrders.get(j).getShares(), sellOrders.get(j).getTransactionID());

                        buyOrders.get(i).setToFill(buyOrders.get(i).getToFill() - sellOrders.get(j).getShares());
                        //give buyer shares
                        sellOrders.get(j).setShares(0);
                        //give seller moolah
                    } else /*more sell than buy*/{
                        if(sellOrders.get(j).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getToFill();
                            MatcherSQL.subtractAvailableShares(amount,ticker);
                        }
                        if(buyOrders.get(i).getTraderID().equals("437238100616282112"))
                        {
                            int amount = buyOrders.get(i).getToFill();
                            MatcherSQL.addAvailableShares(amount,ticker);
                        }
                        MatcherSQL.giveMoney(sellOrders.get(j).getTraderID(), (double) buyOrders.get(i).getToFill() * buyOrders.get(i).getValue());
                        MatcherSQL.giveShares(buyOrders.get(i).getTraderID(), ticker, buyOrders.get(i).getToFill(), buyOrders.get(i).getTransactionID());
                        MatcherSQL.takeShares(sellOrders.get(j).getTraderID(), ticker,buyOrders.get(i).getToFill(), sellOrders.get(j).getTransactionID());

                        sellOrders.get(j).setShares(sellOrders.get(j).getShares() - buyOrders.get(i).getToFill());
                        //give seller moolah
                        //give buyer shares
                        buyOrders.get(i).setToFill(0);
                        j = sellOrders.size();


                    }

                }
            }
        }else{
            //do nothing, just go to FIFO, because all the buy orders can be filled.
        }

        //remove empty orders (IN SQL)


    }
}
